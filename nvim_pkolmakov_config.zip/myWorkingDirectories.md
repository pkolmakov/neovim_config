c:/users/pkolmakov/appdata/local/nvim
c:/users/pkolmakov/documents/OneInc/Docker/scrm/gitlab-claimspay-projects/cp3_workspace/admin_vendor_portal

return {
{"airblade/vim-gitgutter"},
    {"ctrlpvim/ctrlp.vim"},
{"tpope/vim-fugitive"},
    {"low-ghost/nerdtree-fugitive"},
  {
    "aaronhallaert/advanced-git-search.nvim",
    dependencies = {
      "nvim-telescope/telescope.nvim",
      "tpope/vim-fugitive",
      "tpope/vim-rhubarb",
    }
    },
}
